package com.fantac4t.playerstatus.player;

import com.fantac4t.playerstatus.PlayerStatus;
import com.fantac4t.playerstatus.config.PlayerDataConfig;
import eu.pb4.placeholders.api.PlaceholderContext;
import eu.pb4.placeholders.api.Placeholders;
import eu.pb4.placeholders.api.TextParserUtils;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LiveManager {
    private LiveManager() {}

    // URL regex pattern
    private static final Pattern URL_PATTERN = Pattern.compile(
        "https?://(?:[-\\w.])+(?::\\d+)?(?:/[\\w\\-./_%?&=+#]*)?",
        Pattern.CASE_INSENSITIVE
    );

    public static String placeholder(UUID id) {
        return PlayerDataConfig.isLive(id)
                ? safe(PlayerStatus.CONFIG.livePlaceholder)
                : safe(PlayerStatus.CONFIG.notLivePlaceholder);
    }

    public static boolean toggleLive(class_3222 player) {
        UUID id = player.method_5667();
        boolean newState = !PlayerDataConfig.isLive(id);
        PlayerDataConfig.setLive(id, newState);

        if (newState) {
            sendTemplate(player, PlayerStatus.CONFIG.liveOnMessage);
            broadcast(((class_3218) player.method_51469()).method_8503(), player, PlayerStatus.CONFIG.liveBroadcastMessage);
        } else {
            sendTemplate(player, PlayerStatus.CONFIG.liveOffMessage);
        }
        return newState;
    }

    public static boolean togglePersist(class_3222 player) {
        UUID id = player.method_5667();
        boolean v = !PlayerDataConfig.persist(id);
        PlayerDataConfig.setPersist(id, v);
        player.method_64398(
                class_2561.method_43470("Auto live on reconnect: " + (v ? "ENABLED" : "DISABLED"))
                        .method_27692(v ? class_124.field_1060 : class_124.field_1054)
        );
        return v;
    }

    public static void setLink(class_3222 player, String link) {
        PlayerDataConfig.setLink(player.method_5667(), link);
        player.method_64398(class_2561.method_43470("Stream link set."));
    }

    private static void broadcast(MinecraftServer server, class_3222 source, String template) {
        if (server == null || empty(template)) return;

        class_2561 comp = buildMessage(template, source);
        server.method_3760().method_14571().forEach(p -> p.method_64398(comp));
    }

    private static void sendTemplate(class_3222 player, String template) {
        if (empty(template)) return;
        player.method_64398(buildMessage(template, player));
    }

    private static class_2561 buildMessage(String template, class_3222 player) {
        if (empty(template)) return class_2561.method_43473();

        try {
            // 1) Expand your simple custom placeholders first
            String expanded = expandCustomPlaceholders(template, player);
            PlayerStatus.LOGGER.info("[PlayerStatus] After custom expansion: {}", expanded);

            // 2) Ensure plain URLs become MiniMessage-style clickable tags if not already present
            String tagged = ensureClickableUrlTags(expanded);
            PlayerStatus.LOGGER.info("[PlayerStatus] After URL tagging: {}", tagged);

            // 3) Parse tags (colors, hover, click, etc.) using pb4 TextParserUtils
            class_2561 withTags = TextParserUtils.formatText(tagged);

            // 4) Resolve Placeholder API placeholders on the parsed component
            PlaceholderContext context = PlaceholderContext.of(player);
            class_2561 finalComp = Placeholders.parseText(withTags, context);

            return finalComp;
        } catch (Throwable t) {
            PlayerStatus.LOGGER.warn("[PlayerStatus] Message building failed: {}", t.toString());
            return class_2561.method_43470(template);
        }
    }

    // Turn bare URLs into <click:open_url:'...'><underlined><aqua>...</click>
    private static String ensureClickableUrlTags(String input) {
        if (empty(input)) return "";
        // If author already used <click:...> tags, don't double-wrap
        if (input.contains("<click:")) return input;

        StringBuilder sb = new StringBuilder();
        Matcher m = URL_PATTERN.matcher(input);
        int last = 0;

        while (m.find()) {
            int start = m.start();
            int end = m.end();
            String url = input.substring(start, end);

            // Append text before the URL
            if (start > last) sb.append(input, last, start);

            // Wrap the URL in pb4 text tags
            // Note: single quotes around value are required
            sb.append("<aqua><underlined><click:open_url:'")
              .append(url)
              .append("'>")
              .append(url)
              .append("</click></underlined></aqua>");

            last = end;
        }

        // Append any remaining text
        if (last < input.length()) sb.append(input, last, input.length());

        return sb.toString();
    }

    private static String expandCustomPlaceholders(String template, class_3222 player) {
        String result = template;

        // Replace %link% with actual link
        if (result.contains("%link%")) {
            String link = PlayerDataConfig.getLink(player.method_5667());
            result = result.replace("%link%", safe(link));
        }

        // Replace %player_name%
        if (result.contains("%player_name%")) {
            result = result.replace("%player_name%", player.method_5477().getString());
        }

        return result;
    }

    private static boolean empty(String s) {
        return s == null || s.isEmpty();
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}