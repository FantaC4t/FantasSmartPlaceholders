package com.fantac4t.playerstatus.placeholders;

import com.fantac4t.playerstatus.PlayerStatus;
import com.fantac4t.playerstatus.config.PlayerDataConfig;
import com.fantac4t.playerstatus.player.LiveManager;
import eu.pb4.placeholders.api.PlaceholderContext;
import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import eu.pb4.placeholders.api.TextParserUtils;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.net.URI;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

public final class LivePlaceholder {

    private static final class_2960 LIVE_ID = class_2960.method_60655(PlayerStatus.MOD_ID, "live");
    private static final class_2960 STREAM_ID = class_2960.method_60655(PlayerStatus.MOD_ID, "stream");
    private static final class_2960 LIVE_STREAM_ID = class_2960.method_60655(PlayerStatus.MOD_ID, "live_stream");
    private static final class_2960 CLICKABLE_STREAM_ID = class_2960.method_60655(PlayerStatus.MOD_ID, "clickable_stream");

    private LivePlaceholder() {}

    public static void register() {
        // Returns LIVE / not live as a pre-parsed Component
        Placeholders.register(LIVE_ID, (ctx, arg) -> {
            UUID target = resolvePlayerUuid(ctx, arg).orElse(null);
            String raw = LiveManager.placeholder(target);
            return PlaceholderResult.value(parseMini(raw));
        });

        // Returns the raw stream link as literal
        Placeholders.register(STREAM_ID, (ctx, arg) -> {
            UUID target = resolvePlayerUuid(ctx, arg).orElse(null);
            if (target == null || !PlayerDataConfig.isLive(target)) return PlaceholderResult.value(class_2561.method_43473());
            String link = PlayerDataConfig.getLink(target);
            return PlaceholderResult.value(link == null ? class_2561.method_43473() : class_2561.method_43470(link));
        });

        // Emits "LIVE <link>" when live
        Placeholders.register(LIVE_STREAM_ID, (ctx, arg) -> {
            UUID target = resolvePlayerUuid(ctx, arg).orElse(null);
            if (target == null || !PlayerDataConfig.isLive(target)) return PlaceholderResult.value(class_2561.method_43473());
            class_2561 live = parseMini(LiveManager.placeholder(target));
            String link = PlayerDataConfig.getLink(target);
            if (link == null || link.isBlank()) return PlaceholderResult.value(live);
            return PlaceholderResult.value(live.method_27661().method_10852(class_2561.method_43470(" " + link)));
        });

        // Clickable+hoverable link using MiniMessage formatting
        Placeholders.register(CLICKABLE_STREAM_ID, (ctx, arg) -> {
            UUID target = resolvePlayerUuid(ctx, arg).orElse(null);
            if (target == null || !PlayerDataConfig.isLive(target)) return PlaceholderResult.value(class_2561.method_43473());

            String url = normalizeUrl(PlayerDataConfig.getLink(target));
            if (url == null) return PlaceholderResult.value(class_2561.method_43473());

            String label = (arg != null && !arg.isBlank()) ? arg.trim() : "Watch Stream";
            String hover = "Click to open: " + url;
            
            // Use MiniMessage-style formatting that TextParserUtils can parse
            String formatted = "<hover:show_text:'" + esc(hover) + "'><click:open_url:'" + esc(url) + "'><aqua><underlined>" + esc(label) + "</underlined></aqua></click></hover>";
            class_2561 parsed = TextParserUtils.formatText(formatted);
            
            return PlaceholderResult.value(parsed);
        });
    }

    private static Optional<UUID> resolvePlayerUuid(PlaceholderContext ctx, String rawArg) {
        if (rawArg != null && !rawArg.isBlank()) {
            UUID u = tryParseUuid(rawArg.trim());
            if (u != null) return Optional.of(u);
            UUID byName = lookupOnlinePlayerUuid(ctx, rawArg.trim());
            if (byName != null) return Optional.of(byName);
        }
        if (ctx != null && ctx.player() != null) {
            return Optional.of(ctx.player().method_5667());
        }
        return Optional.empty();
    }

    private static UUID tryParseUuid(String s) {
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private static UUID lookupOnlinePlayerUuid(PlaceholderContext ctx, String name) {
        if (ctx == null || ctx.player() == null) return null;
        class_3222 any = ctx.player();
        MinecraftServer server = ((class_3218) any.method_51469()).method_8503();
        if (server == null) return null;
        class_3222 target = server.method_3760().method_14566(name);
        return target != null ? target.method_5667() : null;
    }

    private static class_2561 parseMini(String text) {
        if (text == null || text.isEmpty()) return class_2561.method_43473();
        return TextParserUtils.formatText(text);
    }

    private static final Pattern HTTP = Pattern.compile("(?i)^https?://.+");

    private static String normalizeUrl(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        if (!HTTP.matcher(t).matches()) t = "https://" + t;
        try {
            URI.create(t);
            return t;
        } catch (Exception e) {
            return null;
        }
    }
    
    // Escape single quotes for MiniMessage
    private static String esc(String s) {
        return s.replace("'", "\\'");
    }
}