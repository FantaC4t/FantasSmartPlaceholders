package com.fantac4t.playerstatus.placeholders;

import com.fantac4t.playerstatus.PlayerStatus;
import com.fantac4t.playerstatus.config.PlayerDataConfig;
import com.fantac4t.playerstatus.player.LiveManager;
import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class PlaceholderManager {

    public static void register() {
        // Live status text
        Placeholders.register(id("live"), (ctx, arg) -> {
            if (!ctx.hasPlayer()) return PlaceholderResult.value("");
            return PlaceholderResult.value(LiveManager.placeholder(ctx.player().method_5667()));
        });

        // Raw stream URL (plain)
        Placeholders.register(id("stream"), (ctx, arg) -> {
            if (!ctx.hasPlayer()) return PlaceholderResult.value("");
            String link = PlayerDataConfig.getLink(ctx.player().method_5667());
            return PlaceholderResult.value(link == null ? "" : link);
        });

        // Clickable stream link (currently returns styled text only; click added later by linkifier)
        // If you have a post-parser linkification, this will still become clickable.
        Placeholders.register(id("clickable_stream"), (ctx, arg) -> {
            if (!ctx.hasPlayer()) return PlaceholderResult.value("");
            UUID id = ctx.player().method_5667();
            String url = PlayerDataConfig.getLink(id);
            if (url == null || url.isBlank()) return PlaceholderResult.value("");
            // Just color + underline (no click event to avoid abstract constructor issues)
            return PlaceholderResult.value(
                    class_2561.method_43470(url)
                            .method_27694(s -> s.method_10977(class_124.field_1075).method_30938(true))
            );
        });

        // Colored name (hex tag returned so your later parser can process)
        Placeholders.register(id("coloredname"), (ctx, arg) -> {
            if (!ctx.hasPlayer()) return PlaceholderResult.value("");
            String base = ctx.player().method_5477().getString();
            String hex = PlayerDataConfig.getColor(ctx.player().method_5667());
            if (hex != null && hex.matches("^#?[0-9a-fA-F]{6}$")) {
                if (!hex.startsWith("#")) hex = "#" + hex;
                return PlaceholderResult.value("<" + hex + ">" + base + "</>");
            }
            return PlaceholderResult.value(base);
        });
    }

    private static class_2960 id(String path) {
        // Constructor is private in official mappings
        return class_2960.method_60655(PlayerStatus.MOD_ID, path);
    }

    private PlaceholderManager() {}
}