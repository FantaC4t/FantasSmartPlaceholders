package com.fantac4t.playerstatus.placeholders;

import com.fantac4t.playerstatus.PlayerStatus;
import com.fantac4t.playerstatus.config.PlayerDataConfig;
import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import java.util.UUID;
import net.minecraft.class_2960;

public final class RolePlaceholder {

    private static final class_2960 ROLE_ID =
        class_2960.method_60655(PlayerStatus.MOD_ID, "role");
    private static final class_2960 SUFFIX_ID =
        class_2960.method_60655(PlayerStatus.MOD_ID, "suffix");

    public static void register() {
        Placeholders.register(ROLE_ID, (ctx, arg) -> result(ctx));
        Placeholders.register(SUFFIX_ID, (ctx, arg) -> result(ctx));
    }

    private static PlaceholderResult result(eu.pb4.placeholders.api.PlaceholderContext ctx) {
        if (ctx == null || !ctx.hasPlayer()) {
            return PlaceholderResult.value("");
        }
        UUID id = ctx.player().method_5667();
        String value = PlayerDataConfig.getSuffix(id);
        return PlaceholderResult.value(value != null ? value : "");
    }
}