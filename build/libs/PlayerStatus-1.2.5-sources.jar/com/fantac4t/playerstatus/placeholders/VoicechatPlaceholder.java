package com.fantac4t.playerstatus.placeholders;

import com.fantac4t.playerstatus.PlayerStatus;
import com.fantac4t.playerstatus.voicechat.VoicechatStateManager;
import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import java.util.UUID;
import net.minecraft.class_2960;

public final class VoicechatPlaceholder {

    private static final class_2960 VC_STATUS_ID =
            class_2960.method_60655(PlayerStatus.MOD_ID, "vc_status");

    public static void register() {
        // Single placeholder that reflects the player's current VC state, priority-ordered:
        // 🔊 speaking | 🔇 muted | 📵 disconnected | "" idle/connected
        Placeholders.register(VC_STATUS_ID, (ctx, arg) -> {
            if (!ctx.hasPlayer()) return PlaceholderResult.value("");
            UUID uuid = ctx.player().method_5667();
            if (VoicechatStateManager.isSpeaking(uuid))     return PlaceholderResult.value("🔊");
            if (VoicechatStateManager.isMuted(uuid))        return PlaceholderResult.value("🔇");
            if (VoicechatStateManager.isDisconnected(uuid)) return PlaceholderResult.value("📵");
            return PlaceholderResult.value("");
        });
    }

    private VoicechatPlaceholder() {}
}
