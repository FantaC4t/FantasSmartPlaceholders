package com.fantac4t.playerstatus.placeholders;

import com.fantac4t.playerstatus.PlayerStatus;
import com.fantac4t.playerstatus.config.PlayerDataConfig;
import com.fantac4t.playerstatus.util.RGBColorProcessor;
import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class ColorPlaceholders {
    public static void register() {
        // IMPORTANT: Use "coloredname" without underscore to match decompiled version
        Placeholders.register(class_2960.method_60655(PlayerStatus.MOD_ID, "coloredname"), (ctx, arg) -> {
            if (!ctx.hasPlayer()) {
                return PlaceholderResult.value(class_2561.method_43473());
            }
            String color = PlayerDataConfig.getColor(ctx.player().method_5667());
            return PlaceholderResult.value(RGBColorProcessor.getColoredPlayerName(
                ctx.player().method_5477().getString(), color
            ));
        });
        
        Placeholders.register(class_2960.method_60655(PlayerStatus.MOD_ID, "color"), (ctx, arg) -> {
            if (!ctx.hasPlayer()) {
                return PlaceholderResult.value("");
            }
            String color = PlayerDataConfig.getColor(ctx.player().method_5667());
            return PlaceholderResult.value(color != null ? color : "");
        });
    }
}