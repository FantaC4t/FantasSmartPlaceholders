package com.fantac4t.playerstatus.commands;

import com.fantac4t.playerstatus.player.LiveManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public final class LiveCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("live")
            .executes(ctx -> {
                boolean live = LiveManager.toggleLive(ctx.getSource().method_9207());
                return live ? 1 : 0;
            })
            .then(class_2170.method_9247("autoLiveOnDisconnect")
                .executes(ctx -> {
                    boolean enabled = LiveManager.togglePersist(ctx.getSource().method_9207());
                    return enabled ? 1 : 0;
                }))
            .then(class_2170.method_9247("link")
                .then(class_2170.method_9244("url", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        String link = StringArgumentType.getString(ctx, "url");
                        LiveManager.setLink(ctx.getSource().method_9207(), link);
                        return 1;
                    })))
        );
    }
}