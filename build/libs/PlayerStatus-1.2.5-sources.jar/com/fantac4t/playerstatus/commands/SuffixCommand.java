package com.fantac4t.playerstatus.commands;

import com.fantac4t.playerstatus.config.PlayerDataConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_12099;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class SuffixCommand {

    private static final int MAX_LENGTH = 48;

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(class_2170.method_9247("suffix")
                .requires(src -> src.method_75037().hasPermission(class_12099.field_63210))
                .then(class_2170.method_9247("get")
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(ctx -> {
                                    class_3222 target = class_2186.method_9315(ctx, "player");
                                    String suf = PlayerDataConfig.getSuffix(target.method_5667());
                                    ctx.getSource().method_9226(
                                            () -> class_2561.method_43470("Suffix for " + target.method_5477().getString() + ": " + (suf.isEmpty() ? "<none>" : suf)),
                                            false);
                                    return 1;
                                })
                        )
                )
                .then(class_2170.method_9247("clear")
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(ctx -> {
                                    class_3222 target = class_2186.method_9315(ctx, "player");
                                    PlayerDataConfig.clearSuffix(target.method_5667());
                                    ctx.getSource().method_9226(
                                            () -> class_2561.method_43470("Cleared suffix for " + target.method_5477().getString()),
                                            true);
                                    return 1;
                                })
                        )
                )
                .then(class_2170.method_9244("player", class_2186.method_9305())
                        .then(class_2170.method_9244("text", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    class_3222 target = class_2186.method_9315(ctx, "player");
                                    String input = StringArgumentType.getString(ctx, "text").trim();
                                    final String value = input.length() > MAX_LENGTH ? input.substring(0, MAX_LENGTH) : input;
                                    PlayerDataConfig.setSuffix(target.method_5667(), value);
                                    ctx.getSource().method_9226(
                                            () -> class_2561.method_43470("Set suffix for " + target.method_5477().getString() + " to: " + value),
                                            true);
                                    return 1;
                                })
                        )
                )
        );
    }
}
