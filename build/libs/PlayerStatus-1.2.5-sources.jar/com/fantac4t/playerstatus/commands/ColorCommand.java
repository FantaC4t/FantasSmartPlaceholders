package com.fantac4t.playerstatus.commands;

import com.fantac4t.playerstatus.config.PlayerDataConfig;
import com.fantac4t.playerstatus.util.RGBColorProcessor;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class ColorCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("color")
            .then(class_2170.method_9244("value", StringArgumentType.greedyString())
                .executes(ctx -> {
                    var player = ctx.getSource().method_9207();
                    String value = StringArgumentType.getString(ctx, "value");
                    
                    if (!RGBColorProcessor.isValid(value)) {
                        ctx.getSource().method_9213(class_2561.method_43470("Invalid color value."));
                        return 0;
                    }
                    
                    // Normalize the input by adding # if needed
                    value = RGBColorProcessor.normalizeColorInput(value);
                    
                    PlayerDataConfig.setColor(player.method_5667(), value);
                    
                    // Create a preview message with colored name
                    String playerName = player.method_5477().getString();
                    class_2561 coloredName = RGBColorProcessor.getColoredPlayerName(playerName, value);
                    
                    class_5250 message = class_2561.method_43470("Your color has been set to " + value + ".\nYour name now looks like this: ")
                        .method_10852(coloredName);
                    
                    ctx.getSource().method_9226(() -> message, false);
                    player.method_64398(class_2561.method_43470("Color set to " + value));
                    return 1;
                }))
            .then(class_2170.method_9247("clear")
                .executes(ctx -> {
                    var player = ctx.getSource().method_9207();
                    PlayerDataConfig.clearColor(player.method_5667());
                    ctx.getSource().method_9226(() -> class_2561.method_43470("Color cleared. Your name is now displayed without color."), false);
                    player.method_64398(class_2561.method_43470("Color cleared"));
                    return 1;
                }))
        );
    }
}