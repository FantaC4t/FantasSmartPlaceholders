package com.fantac4t.playerstatus.util;

import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5251;

public final class RGBColorProcessor {
    private static final Pattern HEX_PATTERN = Pattern.compile("#[0-9a-fA-F]{6}");
    private static final Pattern HEX_NO_HASH_PATTERN = Pattern.compile("[0-9a-fA-F]{6}");
    
    public static boolean isValid(String input) {
        if (input == null || input.isEmpty()) {
            return false;
        }
        
        if (input.startsWith("#")) {
            return HEX_PATTERN.matcher(input).matches();
        } else if (HEX_NO_HASH_PATTERN.matcher(input).matches()) {
            // Valid hex code without the # prefix
            return true;
        }
        
        // Legacy color code (like "c" for red)
        return input.length() <= 3;
    }
    
    // Normalize the input by ensuring it has a # prefix if it's a hex code
    public static String normalizeColorInput(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        
        if (!input.startsWith("#") && HEX_NO_HASH_PATTERN.matcher(input).matches()) {
            return "#" + input;
        }
        
        return input;
    }
    
    public static String hexToLegacyCode(String hexColor) {
        hexColor = normalizeColorInput(hexColor);
        
        if (hexColor == null || !HEX_PATTERN.matcher(hexColor).matches()) {
            return "§f";
        }
        
        String hex = hexColor.substring(1);
        StringBuilder legacyCode = new StringBuilder("§x");
        
        for (char c : hex.toCharArray()) {
            legacyCode.append("§").append(c);
        }
        
        return legacyCode.toString();
    }
    
    public static class_2561 getColoredPlayerName(String name, String hexColor) {
        if (hexColor == null || hexColor.isEmpty()) {
            return class_2561.method_43470(name);
        }
        
        // Normalize the color input
        hexColor = normalizeColorInput(hexColor);
        
        if (hexColor.startsWith("#")) {
            if (!HEX_PATTERN.matcher(hexColor).matches()) {
                return class_2561.method_43470(name);
            }
            
            try {
                int rgb = Integer.parseInt(hexColor.substring(1), 16);
                return class_2561.method_43470(name).method_27696(class_2583.field_24360.method_27703(class_5251.method_27717(rgb)));
            } catch (NumberFormatException e) {
                return class_2561.method_43470(name);
            }
        } else {
            return class_2561.method_43470("§" + hexColor + name);
        }
    }
}